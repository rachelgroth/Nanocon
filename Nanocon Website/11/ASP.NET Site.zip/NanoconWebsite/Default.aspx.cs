﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/* Notes:
     content: background-color:#e9f2f9;
     main: background-color:#b2d1e5;
 * 
 * nav: background-color:#3c8dc5;
 * banner: background-color:#FFFFFF;
 */
namespace NanoconWebsite
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}