﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using NanoconWebApp.Objects;

namespace NanoconWebsite
{
    public partial class About : Page
    {
        private List<Event> EventList = new List<Event>();
        /*
        protected void Page_Load(object sender, EventArgs e)
        {
            if (EventList.Count == 0) { FillEventItems(); }
            repEvents.DataSource = EventList;
            repEvents.DataBind();
        }
        
        protected void repEvents_OnItemDataBound(object sender, RepeaterItemEventArgs e) 
        {

            Repeater repSender = (Repeater)sender;
            
            RepeaterItem repItem = (RepeaterItem)e.Item;

            Event eventItem = (Event)repItem.DataItem;

            Label lblName = (Label)repItem.FindControl("lblName");
            Label lblTime = (Label)repItem.FindControl("lblTime");
            Label lblDescription = (Label)repItem.FindControl("lblDescription");

            lblName.Text = eventItem.Name;
            lblTime.Text = Convert.ToString(eventItem.Time);
            lblDescription.Text = eventItem.Description;

        }
        private void FillEventItems() {
            string query = "Select ID, Name, Time, Description From Events";
            AppDomain.CurrentDomain.SetData("DataDirectory", System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data"));

            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename='|DataDirectory|\\Nanocon.mdf';Integrated Security=True");
            
            conn.Open();
            var command = new SqlCommand(query, conn);
                     
            var reader = command.ExecuteReader();

            if (reader.HasRows) {                
                while (reader.Read())
                {
                    Event e = new Event();
                    DateTime? time;
                    e.id = reader.GetInt32(0);
                    e.Name = reader.GetString(1);

                    try
                    {
                        e.Time = reader.GetDateTime(2);
                    }
                    catch {
                        e.Time = null;
                    }
                    
                    e.Description = reader.GetString(3);

                    EventList.Add(e);
                }
            }          

            reader.Close();
            conn.Close();         
        }
        */
    }
}
