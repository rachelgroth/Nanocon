﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NanoconWebApp.Objects
{
    public class Event
    {
        public int id;
        public string Name { get; set; }
        public String Description { get; set; }
        public DayOfWeek Day { get; set; }
        public DateTime? Time { get; set; }

        public Event()
        {


        }
    }
}